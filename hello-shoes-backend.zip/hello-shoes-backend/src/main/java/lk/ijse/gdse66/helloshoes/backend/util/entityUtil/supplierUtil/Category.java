package lk.ijse.gdse66.helloshoes.backend.util.entityUtil.supplierUtil;

public enum Category {
    International,Local
}
