package lk.ijse.gdse66.helloshoes.backend.util.entityUtil;

public enum Gender {
    Male,Female,Other
}
