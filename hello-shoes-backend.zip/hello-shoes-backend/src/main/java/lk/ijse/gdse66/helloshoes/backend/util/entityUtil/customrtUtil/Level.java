package lk.ijse.gdse66.helloshoes.backend.util.entityUtil.customrtUtil;

public enum Level {
    Gold,Silver,Bronze,New
}
