package lk.ijse.gdse66.helloshoes.backend.service.execption;


/**
 * @author: Theekshana De Silva,
 * @Runtime version: 11.0.11+9-b1341.60amd64
 **/
public class ServiceException extends RuntimeException{
    public ServiceException(String message){
        super(message);
    }
}
