package lk.ijse.gdse66.helloshoes.backend.util.entityUtil;

public enum Role {
    ADMIN,USER
}
