package lk.ijse.gdse66.helloshoes.backend.repo;

import lk.ijse.gdse66.helloshoes.backend.entity.AdminPanel;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AdminPanelRepo extends JpaRepository<AdminPanel,String> {
}
